"""
Cortex: A Deep Learning library with CPU and GPU support
"""

from .tensor import Tensor

__version__ = "0.0.1"
__all__ = ["Tensor"]
